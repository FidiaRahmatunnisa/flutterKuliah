package com.fidia.demonstrai1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demonstrai1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
