package com.fidia.uts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UtsApplicationTests {

	@Test
	void contextLoads() {
	}

}
